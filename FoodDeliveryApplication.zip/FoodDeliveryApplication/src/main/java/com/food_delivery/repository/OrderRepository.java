package com.food_delivery.repository;

import com.food_delivery.model.Order;
import com.food_delivery.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    // Define a method to find orders by user
    List<Order> findByUser(User user);
}
