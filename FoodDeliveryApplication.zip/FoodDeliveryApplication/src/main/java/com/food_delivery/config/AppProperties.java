package com.food_delivery.config;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties(prefix = "app")
public class AppProperties {
    private JwtProperties jwt;
    private CartSessionProperties cart;
    private PaymentProperties payment;
	public AppProperties() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AppProperties(JwtProperties jwt, CartSessionProperties cart, PaymentProperties payment) {
		super();
		this.jwt = jwt;
		this.cart = cart;
		this.payment = payment;
	}
	public JwtProperties getJwt() {
		return jwt;
	}
	public void setJwt(JwtProperties jwt) {
		this.jwt = jwt;
	}
	public CartSessionProperties getCart() {
		return cart;
	}
	public void setCart(CartSessionProperties cart) {
		this.cart = cart;
	}
	public PaymentProperties getPayment() {
		return payment;
	}
	public void setPayment(PaymentProperties payment) {
		this.payment = payment;
	}
    
    
}
