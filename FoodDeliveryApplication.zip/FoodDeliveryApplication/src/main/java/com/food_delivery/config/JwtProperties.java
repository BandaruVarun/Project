package com.food_delivery.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "jwt")
public class JwtProperties {

    private String secret;
    private long expiration;

    // Default constructor
    public JwtProperties() {
    }

    // Parameterized constructor
    public JwtProperties(String secret, long expiration) {
        this.secret = secret;
        this.expiration = expiration;
    }

    // Getter for secret
    public String getSecret() {
        return secret;
    }

    // Setter for secret
    public void setSecret(String secret) {
        this.secret = secret;
    }

    // Getter for expiration
    public long getExpiration() {
        return expiration;
    }

    // Setter for expiration
    public void setExpiration(long expiration) {
        this.expiration = expiration;
    }
}
