package com.food_delivery.service;

import com.food_delivery.dto.CartItemRequest;

import com.food_delivery.model.CartItem;
import com.food_delivery.model.User;

import java.util.List;

public interface CartService {
    // Add to cart using User object
    CartItem addToCart(User user, Long foodItemId, int quantity);

    // Add to cart using username and request DTO
    void addToCart(String username, CartItemRequest request);

    // Get cart items by User object
    List<CartItem> getCartItems(User user);

    // Get cart items by username
    List<CartItem> getUserCart(String username);

    // Remove specific cart item by ID
    void removeFromCart(Long cartItemId);

    // Clear all cart items for a given username
    void clearCart(String username);
}
