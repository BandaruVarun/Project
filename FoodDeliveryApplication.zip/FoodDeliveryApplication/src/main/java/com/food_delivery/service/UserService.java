package com.food_delivery.service;

import com.food_delivery.model.User;
import java.util.Optional;

public interface UserService {
    User saveUser(User user);
    Optional<User> findByEmail(String email);
    User findById(Long id);
}
