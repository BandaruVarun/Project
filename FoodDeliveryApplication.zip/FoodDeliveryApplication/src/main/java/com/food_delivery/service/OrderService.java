package com.food_delivery.service;

import com.food_delivery.model.Order;
import com.food_delivery.model.User;

import java.util.List;

public interface OrderService {
    Order placeOrder(User user, String shippingAddress, String paymentMethod);

    List<Order> getOrders(User user);

    Order getOrderById(Long orderId);

    void cancelOrder(Long orderId, User user);

    void updateOrderStatus(Long orderId, String status);
}
