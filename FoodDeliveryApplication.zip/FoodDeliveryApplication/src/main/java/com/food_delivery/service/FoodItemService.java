package com.food_delivery.service;

import com.food_delivery.model.FoodItem;

import java.util.List;

public interface FoodItemService {
    FoodItem addFoodItem(FoodItem foodItem);
    List<FoodItem> getAllFoodItems();
    FoodItem getFoodItemById(Long id);   // Added this for fetching by ID (optional but useful)
    void deleteFoodItem(Long id);
}
