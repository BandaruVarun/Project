package com.food_delivery.controller;

import com.food_delivery.model.CartItem;

import com.food_delivery.model.FoodItem;
import com.food_delivery.model.Order;
import com.food_delivery.model.User;
import com.food_delivery.repository.CartItemRepository;
import com.food_delivery.repository.FoodItemRepository;
import com.food_delivery.repository.UserRepository;
import com.food_delivery.service.OrderService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private FoodItemRepository foodItemRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private OrderService orderService;

    // ✅ View all available food items
    @GetMapping("/all-items")
    public List<FoodItem> getAllFoodItems() {
        return foodItemRepository.findAll();
    }

    // ✅ Add item to cart
    @PostMapping("/add-to-cart/{itemId}")
    public String addToCart(@PathVariable Long itemId, Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));

        FoodItem item = foodItemRepository.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Food item not found"));

        CartItem cartItem = new CartItem();
        cartItem.setUser(user);
        cartItem.setFoodItem(item);
        cartItem.setQuantity(1);

        cartItemRepository.save(cartItem);
        return "Item added to cart successfully!";
    }

    // ✅ View items in cart
    @GetMapping("/cart")
    public List<CartItem> viewCart(Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
        return cartItemRepository.findByUser(user);
    }

    // ✅ Place order from cart using OrderService
    @PostMapping("/place-order")
    public String placeOrder(@RequestParam String shippingAddress,
                             @RequestParam String paymentMethod,
                             Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));

        Order order = orderService.placeOrder(user, shippingAddress, paymentMethod);
        return "Order placed successfully! Order ID: " + order.getId();
    }

    // ✅ View user’s past orders
    @GetMapping("/my-orders")
    public List<Order> getMyOrders(Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
        return orderService.getOrders(user);
    }
}
