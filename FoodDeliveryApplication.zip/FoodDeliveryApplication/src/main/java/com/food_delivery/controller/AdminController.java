package com.food_delivery.controller;

import com.food_delivery.model.FoodItem;

import com.food_delivery.repository.FoodItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private FoodItemRepository foodItemRepository;

    // Admin dashboard test endpoint
    @GetMapping("/dashboard")
    public String adminDashboard() {
        return "Welcome to Admin Dashboard! Only admins can see this.";
    }

    // ✅ Add a new food item
    @PostMapping("/add-item")
    public FoodItem addFoodItem(@RequestBody FoodItem foodItem) {
        return foodItemRepository.save(foodItem);
    }

    // ✅ View all food items
    @GetMapping("/all-items")
    public List<FoodItem> getAllItems() {
        return foodItemRepository.findAll();
    }

    // ✅ Delete food item by ID
    @DeleteMapping("/delete-item/{id}")
    public String deleteItem(@PathVariable Long id) {
        foodItemRepository.deleteById(id);
        return "Item deleted successfully!";
    }
}
