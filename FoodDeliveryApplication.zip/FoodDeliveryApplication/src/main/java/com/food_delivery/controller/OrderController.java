package com.food_delivery.controller;

import com.food_delivery.dto.PlaceOrderRequest;
import com.food_delivery.model.Order;
import com.food_delivery.model.User;
import com.food_delivery.repository.UserRepository;
import com.food_delivery.security.JwtUtil;
import com.food_delivery.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    // Place Order and store it directly in the User's orders list
    @PostMapping("/place")
    public Order placeOrder(@RequestHeader("Authorization") String token,
                            @Valid @RequestBody PlaceOrderRequest request) {
        String jwtToken = token.substring(7); // Extract JWT from header
        String email = jwtUtil.extractUsername(jwtToken); // Get email from token
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found!"));

        // Create a new Order, link it to the User, and store it directly in the User entity
        Order order = orderService.placeOrder(user, request.getShippingAddress(), request.getPaymentMethod());

        // Add the order to the user's orders list
        user.getOrders().add(order);  // Assuming you have a List<Order> in the User entity
        userRepository.save(user);  // Save the user with the new order in the database

        return order; // Return the created order
    }

    // Get all orders of the logged-in user
    @GetMapping("/my-orders")
    public List<Order> getMyOrders(@RequestHeader("Authorization") String token) {
        String jwtToken = token.substring(7); // Extract JWT from header
        String email = jwtUtil.extractUsername(jwtToken); // Get email from token
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found!"));

        return orderService.getOrders(user); // Retrieve orders linked to the user
    }

    // Get Order by ID
    @GetMapping("/{orderId}")
    public Order getOrderById(@PathVariable Long orderId) {
        return orderService.getOrderById(orderId);
    }

    // Cancel an Order
    @PutMapping("/cancel/{orderId}")
    public String cancelOrder(@RequestHeader("Authorization") String token, @PathVariable Long orderId) {
        String jwtToken = token.substring(7); // Extract JWT from header
        String email = jwtUtil.extractUsername(jwtToken); // Get email from token
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found!"));

        orderService.cancelOrder(orderId, user); // Cancel the order for the specific user
        return "Order cancelled successfully!";
    }

    // Update Order Status (Admin Only)
    @PutMapping("/update-status/{orderId}")
    public String updateOrderStatus(@PathVariable Long orderId, @RequestParam String status) {
        orderService.updateOrderStatus(orderId, status); // Update order status
        return "Order status updated to " + status;
    }
}
