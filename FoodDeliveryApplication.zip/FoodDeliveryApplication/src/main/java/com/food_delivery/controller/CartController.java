package com.food_delivery.controller;

import com.food_delivery.dto.CartItemRequest;

import com.food_delivery.model.CartItem;
import com.food_delivery.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    // ✅ Add item to cart
    @PostMapping("/add")
    public String addToCart(@RequestBody CartItemRequest request, Principal principal) {
        String username = principal.getName();
        cartService.addToCart(username, request);
        return "Item added to cart!";
    }

    // ✅ View cart items for the logged-in user
    @GetMapping("/view")
    public List<CartItem> viewCart(Principal principal) {
        String username = principal.getName();
        return cartService.getUserCart(username);
    }

    // ✅ Clear all cart items for the logged-in user
    @DeleteMapping("/clear")
    public String clearCart(Principal principal) {
        String username = principal.getName();
        cartService.clearCart(username);
        return "Cart cleared!";
    }

    // ✅ Remove a specific item from cart by its cart item ID
    @DeleteMapping("/remove/{cartItemId}")
    public String removeItemFromCart(@PathVariable Long cartItemId) {
        cartService.removeFromCart(cartItemId);
        return "Item removed from cart!";
    }
}
