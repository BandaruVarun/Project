package com.food_delivery;

import com.food_delivery.config.JwtProperties;


import com.food_delivery.config.CartSessionProperties;
import com.food_delivery.config.PaymentProperties;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties({JwtProperties.class, CartSessionProperties.class, PaymentProperties.class})
public class FoodDeliveryApplication {
    public static void main(String[] args) {
        SpringApplication.run(FoodDeliveryApplication.class, args);
    }
}
