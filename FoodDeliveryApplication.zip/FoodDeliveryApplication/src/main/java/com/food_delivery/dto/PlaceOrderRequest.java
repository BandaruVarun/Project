package com.food_delivery.dto;

import jakarta.validation.constraints.NotEmpty;

public class PlaceOrderRequest {

    @NotEmpty(message = "Shipping address cannot be empty")
    private String shippingAddress;

    @NotEmpty(message = "Payment method cannot be empty")
    private String paymentMethod;

    // Getters and Setters
    public String getShippingAddress() { return shippingAddress; }
    public void setShippingAddress(String shippingAddress) { this.shippingAddress = shippingAddress; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
}
