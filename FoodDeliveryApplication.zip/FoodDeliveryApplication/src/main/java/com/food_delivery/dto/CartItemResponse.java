package com.food_delivery.dto;

public class CartItemResponse {
    private Long id;
    private String foodName;
    private double price;
    private int quantity;
    private double total;
    private String imageUrl;

    // No-args constructor
    public CartItemResponse() {
    }

    // All-args constructor
    public CartItemResponse(Long id, String foodName, double price, int quantity, String imageUrl) {
        this.id = id;
        this.foodName = foodName;
        this.price = price;
        this.quantity = quantity;
        this.total = price * quantity;
        this.imageUrl = imageUrl;
    }

    // Getters & Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        this.total = this.price * this.quantity; // Recalculate total if quantity changes
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Override
    public String toString() {
        return "CartItemResponse{" +
                "id=" + id +
                ", foodName='" + foodName + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                ", total=" + total +
                ", imageUrl='" + imageUrl + '\'' +
                '}';
    }
}
