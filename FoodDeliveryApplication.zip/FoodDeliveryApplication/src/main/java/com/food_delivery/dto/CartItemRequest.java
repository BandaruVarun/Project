package com.food_delivery.dto;

public class CartItemRequest {
    private Long foodId;
    private int quantity;

    // No-args constructor
    public CartItemRequest() {
    }

    // All-args constructor
    public CartItemRequest(Long foodId, int quantity) {
        this.foodId = foodId;
        this.quantity = quantity;
    }

    // Getter for foodId
    public Long getFoodId() {
        return foodId;
    }

    // Setter for foodId
    public void setFoodId(Long foodId) {
        this.foodId = foodId;
    }

    // Getter for quantity
    public int getQuantity() {
        return quantity;
    }

    // Setter for quantity
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // toString method
    @Override
    public String toString() {
        return "CartItemRequest{" +
                "foodId=" + foodId +
                ", quantity=" + quantity +
                '}';
    }
}
